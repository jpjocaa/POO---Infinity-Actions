 
using UnityEngine;
using TMPro;
using UnityEngine.UI;


public class Eventos
{
    EventsOptions OpcoesDeEventos = new();
    ConfigButtons editarBotao = new();
    public void EventoBoaVindas(TMP_Text mensagem, Button[] botoes, GameManager manager)
    {
        mensagem.text = "Seja bem vindo ao nosso jogo!!\nEle foi feito com muito carinho e dedicação, afinal, isso foi algo totalmente novo, então aproveite!";
        editarBotao.ConfigurarBotao(1, "Clique no botão para prosseguir", manager.IniciarJogo , botoes);
    }

    public void AnimalFeroz(TMP_Text mensagem, Button[] botoes, GameManager manager) //Seria daora fazer uma classe subeventos para detalhar mais os acontecimentos.
    {
        mensagem.text = "Oh não,eu encontrei um animal feroz!";
        editarBotao.ConfigurarBotao(0 , "1- Corrrer para longe", OpcoesDeEventos.Prosseguir, botoes);
        editarBotao.ConfigurarBotao(1 , "2- Desviar rapidamente", OpcoesDeEventos.Prosseguir, botoes);
        editarBotao.ConfigurarBotao(2 , "3- Pular o animal", OpcoesDeEventos.Prosseguir, botoes);
        editarBotao.ConfigurarBotao(3 , "4- Voltar silenciosamente", OpcoesDeEventos.Prosseguir, botoes);
        editarBotao.ConfigurarBotao(4 , "5- Esconder-se", OpcoesDeEventos.Prosseguir, botoes);
        editarBotao.ConfigurarBotao(5 , "6- Tentar capturar o animal", OpcoesDeEventos.Prosseguir, botoes);
        
    }

}