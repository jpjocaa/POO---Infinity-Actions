using UnityEngine;
using UnityEngine.UI;
using TMPro;


public class EventsOptions
{
    private GameManager manager;


    public void Prosseguir()
    {
        Debug.Log("Prosseguindo...");
        
    }

    public void CalcularSucesso()
    {
        //o metodo que o configurar botão do direction usaria. Se der sucesso, prossegue, caso contrario, iria de alguma forma acabar o jogo.
    }
}